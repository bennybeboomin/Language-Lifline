window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('year')?.textContent = new Date().getFullYear();
  // Filters & searches for stories can be added here
});
